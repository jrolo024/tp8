let button = document.getElementsByTagName("button")[0];
button.onclick = function(){button.style.backgroundColor = `rgb(${Math.random()*255}, ${Math.random()*255}, ${Math.random()*255})`};
